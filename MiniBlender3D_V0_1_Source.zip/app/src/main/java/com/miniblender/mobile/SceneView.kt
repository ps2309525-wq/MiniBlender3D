package com.miniblender.mobile

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

private data class Obj(val kind:String,var x:Float=0f,var y:Float=0f,var angle:Float=0f,var size:Float=1f,var rgb:FloatArray=floatArrayOf(.32f,.40f,.85f))

class SceneView(c:Context):GLSurfaceView(c){
    private val r=SceneRenderer()
    private var lx=0f; private var ly=0f; private var pinch=0f
    init{setEGLContextClientVersion(2);setRenderer(r);renderMode=RENDERMODE_CONTINUOUSLY}
    fun add(s:String)=r.add(s); fun delete()=r.delete(); fun color(a:Float,b:Float,c:Float)=r.color(a,b,c)
    fun adjust(m:String,v:Float)=r.adjust(m,v); fun reset()=r.reset(); fun undo()=r.undo()
    override fun onTouchEvent(e:MotionEvent):Boolean{
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN->{lx=e.x;ly=e.y;return true}
            MotionEvent.ACTION_POINTER_DOWN->{if(e.pointerCount>1)pinch=dist(e);return true}
            MotionEvent.ACTION_MOVE->{
                if(e.pointerCount>1){val d=dist(e);if(pinch>0)r.zoom((pinch-d)*.012f);pinch=d}
                else{r.orbit((e.x-lx)*.45f,(e.y-ly)*.45f);lx=e.x;ly=e.y};return true
            }
            MotionEvent.ACTION_UP->{performClick();return true}
        };return true
    }
    override fun performClick():Boolean{super.performClick();return true}
    private fun dist(e:MotionEvent):Float{val x=e.getX(0)-e.getX(1);val y=e.getY(0)-e.getY(1);return sqrt(x*x+y*y)}
}

private class SceneRenderer:GLSurfaceView.Renderer{
    private val objects= mutableListOf<Obj>(); private val undo= mutableListOf<List<Obj>>()
    private var selected=-1; private var ax=24f;private var ay=-35f;private var zoom=6f
    private var program=0;private val proj=FloatArray(16);private val view=FloatArray(16);private val model=FloatArray(16);private val mvp=FloatArray(16)
    @Synchronized fun add(k:String){saveUndo();objects.add(Obj(k,x=((objects.size%3)-1)*.45f));selected=objects.lastIndex}
    @Synchronized fun delete(){if(selected in objects.indices){saveUndo();objects.removeAt(selected);selected=objects.lastIndex}}
    @Synchronized fun color(r:Float,g:Float,b:Float){if(selected in objects.indices){saveUndo();objects[selected].rgb=floatArrayOf(r,g,b)}}
    @Synchronized fun adjust(mode:String,v:Float){if(selected !in objects.indices)return;val o=objects[selected];when(mode){"MOVE"->o.x+=v*.04f;"ROTATE"->o.angle+=v*5f;"SCALE"->o.size=(o.size+v*.025f).coerceIn(.2f,3f)}}
    @Synchronized fun orbit(dx:Float,dy:Float){ay+=dx;ax=(ax+dy).coerceIn(-85f,85f)}
    @Synchronized fun zoom(v:Float){zoom=(zoom+v).coerceIn(2.5f,12f)}
    @Synchronized fun reset(){ax=24f;ay=-35f;zoom=6f}
    @Synchronized fun undo(){if(undo.isNotEmpty()){val a=undo.removeAt(undo.lastIndex);objects.clear();objects.addAll(a.map{it.copy(rgb=it.rgb.copyOf())});selected=objects.lastIndex}}
    private fun saveUndo(){undo.add(objects.map{it.copy(rgb=it.rgb.copyOf())});if(undo.size>15)undo.removeAt(0)}
    override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){
        GLES20.glClearColor(.95f,.96f,.98f,1f);GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs="attribute vec3 p; uniform mat4 m; void main(){gl_Position=m*vec4(p,1.0);}"
        val fs="precision mediump float; uniform vec4 c; void main(){gl_FragColor=c;}"
        val v=compile(GLES20.GL_VERTEX_SHADER,vs);val f=compile(GLES20.GL_FRAGMENT_SHADER,fs)
        program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program)
    }
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,45f,w.toFloat()/max(1,h),.1f,100f)}
    override fun onDrawFrame(gl:GL10?){
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setLookAtM(view,0,0f,0f,zoom,0f,0f,0f,0f,1f,0f);GLES20.glUseProgram(program)
        val ap=GLES20.glGetAttribLocation(program,"p");val um=GLES20.glGetUniformLocation(program,"m");val uc=GLES20.glGetUniformLocation(program,"c")
        val list=synchronized(this){objects.map{it.copy(rgb=it.rgb.copyOf())}}
        list.forEachIndexed{i,o->
            val a=geometry(o.kind);val b=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer();b.put(a).position(0)
            Matrix.setIdentityM(model,0);Matrix.translateM(model,0,o.x,o.y,0f);Matrix.rotateM(model,0,ax,1f,0f,0f);Matrix.rotateM(model,0,ay+o.angle,0f,1f,0f);Matrix.scaleM(model,0,o.size,o.size,o.size)
            Matrix.multiplyMM(mvp,0,view,0,model,0);Matrix.multiplyMM(mvp,0,proj,0,mvp,0);GLES20.glUniformMatrix4fv(um,1,false,mvp,0)
            val c=if(i==selected)floatArrayOf(min(1f,o.rgb[0]+.12f),min(1f,o.rgb[1]+.12f),min(1f,o.rgb[2]+.12f),1f) else floatArrayOf(o.rgb[0],o.rgb[1],o.rgb[2],1f)
            GLES20.glUniform4fv(uc,1,c,0);GLES20.glEnableVertexAttribArray(ap);GLES20.glVertexAttribPointer(ap,3,GLES20.GL_FLOAT,false,0,b);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,a.size/3);GLES20.glDisableVertexAttribArray(ap)
        }
    }
    private fun compile(t:Int,s:String):Int{val id=GLES20.glCreateShader(t);GLES20.glShaderSource(id,s);GLES20.glCompileShader(id);return id}
    private fun geometry(k:String):FloatArray{
        val out=ArrayList<Float>()
        fun tri(a:FloatArray,b:FloatArray,c:FloatArray){for(p in listOf(a,b,c))for(v in p)out.add(v)}
        fun quad(a:FloatArray,b:FloatArray,c:FloatArray,d:FloatArray){tri(a,b,c);tri(a,c,d)}
        if(k=="Cube"){
            val p=arrayOf(floatArrayOf(-1f,-1f,1f),floatArrayOf(1f,-1f,1f),floatArrayOf(1f,1f,1f),floatArrayOf(-1f,1f,1f),floatArrayOf(-1f,-1f,-1f),floatArrayOf(1f,-1f,-1f),floatArrayOf(1f,1f,-1f),floatArrayOf(-1f,1f,-1f))
            quad(p[0],p[1],p[2],p[3]);quad(p[5],p[4],p[7],p[6]);quad(p[4],p[0],p[3],p[7]);quad(p[1],p[5],p[6],p[2]);quad(p[3],p[2],p[6],p[7]);quad(p[4],p[5],p[1],p[0])
        }else{
            val n=20
            for(i in 0 until n){val a=2*PI.toFloat()*i/n;val b=2*PI.toFloat()*(i+1)/n
                val p1=floatArrayOf(cos(a),-1f,sin(a));val p2=floatArrayOf(cos(b),-1f,sin(b))
                val p3=floatArrayOf(cos(b),1f,sin(b));val p4=floatArrayOf(cos(a),1f,sin(a))
                if(k=="Sphere"){
                    for(j in 0 until 10){val t1=PI.toFloat()*j/10;val t2=PI.toFloat()*(j+1)/10
                        fun pt(t:Float,q:Float)=floatArrayOf(sin(t)*cos(q),cos(t),sin(t)*sin(q))
                        val q1=pt(t1,a);val q2=pt(t2,a);val q3=pt(t2,b);val q4=pt(t1,b);quad(q1,q2,q3,q4)
                    }
                }else if(k=="Cone"){tri(floatArrayOf(0f,1f,0f),p1,p2);tri(floatArrayOf(0f,-1f,0f),p2,p1)}
                else{quad(p1,p2,p3,p4);tri(floatArrayOf(0f,-1f,0f),p2,p1)}
            }
        };return out.toFloatArray()
    }
}
