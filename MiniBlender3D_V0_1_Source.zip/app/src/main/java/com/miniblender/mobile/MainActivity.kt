package com.miniblender.mobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var scene: SceneView
    private var transform = "MOVE"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(243,245,250)
        window.navigationBarColor = Color.rgb(243,245,250)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF3F5FA.toInt()) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14,4,14,4); setBackgroundColor(Color.WHITE) }
        header.addView(TextView(this).apply { text = "◈  MiniBlender 3D"; textSize = 19f; setTextColor(0xFF20273A.toInt()); setTypeface(null,1) },
            LinearLayout.LayoutParams(0,48,1f))
        header.addView(btn("Save") { Toast.makeText(this,"Project saving will be added in V0.2",Toast.LENGTH_SHORT).show() })
        root.addView(header)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scene = SceneView(this)
        body.addView(scene, LinearLayout.LayoutParams(0,-1,1f))
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,8,8,8); setBackgroundColor(Color.WHITE) }
        panel.addView(section("ADD OBJECT"))
        row(panel, btn("+ Cube"){scene.add("Cube")}, btn("+ Sphere"){scene.add("Sphere")})
        row(panel, btn("+ Cylinder"){scene.add("Cylinder")}, btn("+ Cone"){scene.add("Cone")})
        panel.addView(section("TRANSFORM"))
        row(panel, btn("Move"){transform="MOVE"}, btn("Rotate"){transform="ROTATE"})
        row(panel, btn("Scale"){transform="SCALE"}, btn("Delete"){scene.delete()})
        panel.addView(TextView(this).apply { text="Adjust selected object"; textSize=11f; setTextColor(0xFF667085.toInt()) })
        panel.addView(SeekBar(this).apply {
            max=100; progress=50
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s:SeekBar?, p:Int, user:Boolean) { if(user) scene.adjust(transform,(p-50)/50f) }
                override fun onStartTrackingTouch(s:SeekBar?) {}
                override fun onStopTrackingTouch(s:SeekBar?) {}
            })
        })
        panel.addView(section("MATERIAL COLOR"))
        row(panel, color("#5367D8"){scene.color(.32f,.40f,.85f)}, color("#E78B4A"){scene.color(.90f,.48f,.22f)}, color("#42A889"){scene.color(.20f,.66f,.52f)})
        row(panel, color("#E6B94D"){scene.color(.90f,.70f,.25f)}, color("#D85D70"){scene.color(.82f,.28f,.40f)}, color("#8993A6"){scene.color(.50f,.55f,.64f)})
        panel.addView(section("VIEW"))
        row(panel, btn("Reset View"){scene.reset()}, btn("Undo"){scene.undo()})
        panel.addView(TextView(this).apply { text="Drag: orbit  •  Pinch: zoom"; textSize=10f; setTextColor(0xFF667085.toInt()); setPadding(2,8,2,2) })
        body.addView(panel,LinearLayout.LayoutParams(250,-1))
        root.addView(body,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        scene.add("Cube")
    }
    private fun section(s:String)=TextView(this).apply{text=s;textSize=11f;setTypeface(null,1);setTextColor(0xFF667085.toInt());setPadding(3,9,3,4)}
    private fun btn(s:String, f:()->Unit)=Button(this).apply{text=s;textSize=11f;isAllCaps=false;setOnClickListener{f()};layoutParams=LinearLayout.LayoutParams(0,42,1f).apply{setMargins(2,2,2,2)}}
    private fun color(hex:String,f:()->Unit)=Button(this).apply{text="●";textSize=17f;isAllCaps=false;setTextColor(Color.parseColor(hex));setOnClickListener{f()};layoutParams=LinearLayout.LayoutParams(0,38,1f).apply{setMargins(2,2,2,2)}}
    private fun row(p:LinearLayout,vararg v:View){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};v.forEach{r.addView(it)};p.addView(r)}
}
