# MiniBlender 3D — V0.1 starter

A native Android Studio project for a lightweight, touch-first 3D editor.

### Included
- Light theme, landscape workspace
- OpenGL ES 2.0 viewport
- Add Cube, Sphere, Cylinder, Cone
- Drag to orbit; pinch to zoom
- Move / Rotate / Scale adjustment slider
- Basic material color palette
- Delete and Undo

### Build and install
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Open this project folder in Android Studio.
3. Install Android SDK Platform 35 when prompted and allow Gradle sync.
4. Connect the Android phone with USB debugging enabled.
5. Press Run to install on the phone.
6. For an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).

### Current prototype limitations
V0.1 is an early working viewport prototype, not a full Blender replacement. Object selection is currently the most recently added object. The Save button is a placeholder; persistent project saving, mesh editing, numeric transform fields, sculpting, animation, and production-quality rendering are planned for later versions. Rendering currently uses simple flat colors and does not yet include real material shaders or lighting.
